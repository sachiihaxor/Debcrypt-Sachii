# Debcrypt
A script crack bcrypt hash. 
![Demo](https://s2.anh.im/2017/08/05/Screenshot_2017-08-05_03-17-231f72b.png)
