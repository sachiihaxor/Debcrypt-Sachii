#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from passlib.hash import bcrypt
from libs import pingo
from colored import fg
import sys

color = fg('#FF8849')

print(color + "\n*************************************************")
print(color + "Debcrypt - Password Crack by ./Sachii'Xploit")
print(color + "*************************************************")
options = input(color + '\nApakah ingin Crack? y/n: ')

if (options == "n"):
    sys.exit()
elif (options != "y" and options != "n"):
    sys.exit(color + 'Salah Ketik!')

passwords = (options == "y")
text_file = open("pass.txt", "r", encoding="cp437")

words = text_file.read().splitlines()

hash = input(color + 'Taruh disini type Debcrypt: ')
length = len(words)

correct_word = ""
found = 0
for (index, word) in enumerate(words):
    pingo(index, length, prefix='Wait:', suffix='Kata-kata lengkap dari daftar')
    correct = bcrypt.verify(word, hash)
    if (correct):
        correct_word = word
        found += 1
        break

if (found == 1):
    print(color + "\n\nPassword Sudah Ketemu!")
    print(color + "Results:", correct_word)
else:
    print(color + "\n\nPassword Tidak Ditemukan")
